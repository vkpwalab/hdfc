import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-projects',
  templateUrl: './dashboard-projects.component.html',
  styleUrls: ['./dashboard-projects.component.css']
})
export class DashboardProjectsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
